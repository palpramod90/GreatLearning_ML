#
# Licensed to the Apache Software Foundation (ASF) under one
# or more contributor license agreements.  See the NOTICE file
# distributed with this work for additional information
# regarding copyright ownership.  The ASF licenses this file
# to you under the Apache License, Version 2.0 (the
# "License"); you may not use this file except in compliance
# with the License.  You may obtain a copy of the License at
#
#   http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing,
# software distributed under the License is distributed on an
# "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
# KIND, either express or implied.  See the License for the
# specific language governing permissions and limitations
# under the License.
"""Task Instance APIs."""
from __future__ import annotations

import warnings

from airflow.api.common.mark_tasks import (  # noqa
    _create_dagruns,
    set_dag_run_state_to_failed,
    set_dag_run_state_to_running,
    set_dag_run_state_to_success,
    set_state,
)

warnings.warn(
    "This module is deprecated. Please use `airflow.api.common.mark_tasks` instead.",
    DeprecationWarning,
    stacklevel=2,
)
