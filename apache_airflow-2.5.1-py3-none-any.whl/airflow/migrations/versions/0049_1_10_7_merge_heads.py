#
# Licensed to the Apache Software Foundation (ASF) under one
# or more contributor license agreements.  See the NOTICE file
# distributed with this work for additional information
# regarding copyright ownership.  The ASF licenses this file
# to you under the Apache License, Version 2.0 (the
# "License"); you may not use this file except in compliance
# with the License.  You may obtain a copy of the License at
#
#   http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing,
# software distributed under the License is distributed on an
# "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
# KIND, either express or implied.  See the License for the
# specific language governing permissions and limitations
# under the License.
"""Straighten out the migrations

Revision ID: 08364691d074
Revises: a56c9515abdc, 004c1210f153, 74effc47d867, b3b105409875
Create Date: 2019-11-19 22:05:11.752222

"""
from __future__ import annotations

# revision identifiers, used by Alembic.
revision = "08364691d074"
down_revision = ("a56c9515abdc", "004c1210f153", "74effc47d867", "b3b105409875")
branch_labels = None
depends_on = None
airflow_version = "1.10.7"


def upgrade():
    pass


def downgrade():
    pass
